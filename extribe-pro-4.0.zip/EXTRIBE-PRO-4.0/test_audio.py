from pathlib import Path
from playwright.sync_api import sync_playwright
import wave,struct,math,json
root=Path(__file__).parent/'web'
wav=Path('/tmp/extribe-test-sine.wav')
with wave.open(str(wav),'wb') as f:
 f.setnchannels(1);f.setsampwidth(2);f.setframerate(44100);f.writeframes(b''.join(struct.pack('<h',int(9000*math.sin(2*math.pi*440*i/44100))) for i in range(4410)))
html=(root/'index.html').read_text().replace('<link rel="stylesheet" href="app.css">','<style>'+(root/'app.css').read_text()+'</style>').replace('<script src="app.js" defer></script>','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']);page=b.new_page(accept_downloads=True);err=[];page.on('pageerror',lambda e:err.append(str(e)))
 page.set_content(html);page.add_script_tag(content=(root/'app.js').read_text())
 page.locator('.seq-row[data-pad="0"] .load-sample').click(force=True)
 page.locator('#samplePicker').set_input_files(str(wav));page.wait_for_timeout(400)
 print('pad',page.evaluate('window.EXTRIBETest.serialize().banks[0][0].sampleName'))
 print('samples',page.evaluate('window.EXTRIBETest.getState().samples'))
 page.locator('.seq-row[data-pad="0"] .step[data-step="0"]').click(force=True)
 page.locator('#playButton').click(force=True);page.wait_for_timeout(300);page.locator('#stopButton').click(force=True)
 page.locator('#menuButton').click(force=True);page.locator('[data-action="save"]').click(force=True);page.wait_for_timeout(600)
 print('save text',page.locator('#saveStatus').inner_text(),'toast',page.locator('#toast').inner_text())
 page.locator('#menuButton').click(force=True)
 with page.expect_download(timeout=10000) as dl:
  page.locator('[data-action="export"]').click(force=True)
 print('download',dl.value.suggested_filename,'size',dl.value.path().stat().st_size)
 page.locator('#menuButton').click(force=True)
 with page.expect_download(timeout=12000) as dl:
  page.locator('[data-action="wav"]').click(force=True)
 print('WAV',dl.value.suggested_filename,'size',dl.value.path().stat().st_size)
 print('errors',err)
 assert not err
 b.close()
