from playwright.sync_api import sync_playwright
from pathlib import Path
import json
root=Path(__file__).parent/'web'
html=(root/'index.html').read_text()
css=(root/'app.css').read_text()
js=(root/'app.js').read_text()
html=html.replace('<link rel="stylesheet" href="app.css">','<style>'+css+'</style>').replace('<script src="app.js" defer></script>','')
report={}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,has_touch=True,is_mobile=True)
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded')
    page.add_script_tag(content=js)
    page.wait_for_timeout(200)
    state=page.evaluate('window.EXTRIBETest.getState()')
    assert state['samples']==0 and state['activeSteps']==0 and state['fx']==False and state['mutes']==0
    assert page.locator('.seq-row').count()==16
    assert page.locator('.step').count()==16*16
    report['blank_start']=state
    page.locator('.seq-row[data-pad="0"] .step[data-step="0"]').click(force=True)
    assert page.evaluate('window.EXTRIBETest.getState().activeSteps')==1
    page.locator('.seq-row[data-pad="0"] .mute').click(force=True)
    assert page.evaluate('window.EXTRIBETest.getState().mutes')==1
    page.locator('button[data-view="live"]').click(force=True)
    assert page.locator('.pad-card').count()==16
    assert page.locator('.pad-card[data-pad="0"] .mute.off').count()==1
    report['sequencer_and_live']='16 rows, 16 live pads, mute synchronized'
    page.locator('button[data-bank="1"]').click(force=True)
    assert page.evaluate('window.EXTRIBETest.getState().activeSteps')==1
    assert page.locator('.pad-card[data-pad="0"] .mute.off').count()==0
    page.locator('button[data-view="steps"]').click(force=True)
    assert page.locator('.step.on').count()==0
    page.select_option('#stepLength','32')
    assert page.locator('.step').count()==16*32
    report['banks_and_length']='4 bank buttons, 32 step mode works'
    page.locator('#menuButton').click(force=True)
    page.locator('#menu button[data-action="tutorial"]').click(force=True)
    assert page.locator('#dialogContent').inner_text().find('Start:')>=0
    page.locator('#closeDialog').click(force=True)
    report['tutorial']='opens and closes'
    page.locator('button[data-view="mixer"]').click(force=True)
    assert not page.locator('#fxEnable').is_checked()
    assert not page.locator('#filterCutoff').is_enabled()
    page.locator('#fxEnable').check(force=True)
    assert page.evaluate('window.EXTRIBETest.getState().fx')==True
    assert page.locator('#filterCutoff').is_enabled()
    report['effects']='default off; enable works'
    page.evaluate('window.EXTRIBETest.reset()')
    assert page.evaluate('window.EXTRIBETest.getState().samples')==0
    assert page.evaluate('window.EXTRIBETest.getState().fx')==False
    assert page.evaluate('window.EXTRIBETest.getState().activeSteps')==0
    report['reset']='everything blank again'
    # Test IndexedDB save and reload, but content iframe about blank may not permit IndexedDB; test with local storage separately.
    page.screenshot(path=str(Path(__file__).parent/'iphone-preview.png'),full_page=True)
    assert not errors,errors
    report['js_errors']=errors
    browser.close()
print(json.dumps(report,ensure_ascii=False,indent=2))
