const CACHE='extribe-pro-4.0-static-v1';
const FILES=['./','./index.html','./app.css','./app.js','./icon.png','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
 event.respondWith(fetch(event.request).then(resp=>{
   if(resp.ok&&new URL(event.request.url).pathname.match(/\.(?:html|css|js|png|webmanifest)$/)){
     const clone=resp.clone();caches.open(CACHE).then(c=>c.put(event.request,clone)).catch(()=>{});
   }
   return resp;
 }).catch(()=>caches.match(event.request).then(cached=>cached||caches.match('./index.html'))));
});
