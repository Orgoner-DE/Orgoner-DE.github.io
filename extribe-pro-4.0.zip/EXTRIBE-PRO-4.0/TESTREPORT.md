# EX-TRIBE PRO 4.0 | Tests

## Lokal im Chromium-DOM-/Audio-Test
- Leerer Start (0 Samples, 0 Steps, FX aus)
- 16 Zeilen und je 16/32 Step-Schalter
- Bankwechsel A/B/C/D
- Mute gleich im Live-/Step-Modus
- Tutorial öffnen/schließen
- Master-FX standardmäßig deaktiviert
- Rücksetzen auf leeren Zustand
- Test-WAV laden und abspielen
- Projekt-Export JSON und Stereo-WAV-Export
- JavaScript-Konsole ohne Seitenfehler

## Nicht lokal geprüft
- iPhone-/iPad-Hardware-Audiolatenz
- Installation einer signierten IPA (Apple-Anmeldung erforderlich)
- Android-Hardwaredateiauswahl und Dateispeicherung

Automatisierte Android- und iOS-Build-Ergebnisse werden separat berichtet.
