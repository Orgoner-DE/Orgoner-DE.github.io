# EX-TRIBE PRO 4.0 | Android / iOS / Safari

## Was ist neu?

- Startet immer komplett leer: 4 Bänke × 16 Pads, keine Samples, Steps oder Effekte.
- 16 Pad-Spuren stehen untereinander, je Spur Sample-Import, Mute und 16/32 Step-Tasten.
- Live-Pads mit grüner Mute-Schaltfläche (rot = stumm), Bank A-D.
- Menü: lokal speichern, gespeichertes Projekt laden, JSON-Import/Export, WAV-Loop exportieren, Pattern kopieren, Bank leeren, alles zurücksetzen, Tutorial.
- iOS-freundliche Bedienung und Web-Audio: Audio wird nur nach Tippen aktiviert, sanfte Hüllkurve, Kompressor als Übersteuerungsschutz, FX standardmäßig AUS. Optional Filter/Delay.
- Native Datei-Import-/Export-Brücken für Android und iOS. Native Projektspeicherung auf beiden Plattformen.

## Dateien

- `web/` HTTPS-fähige PWA für Safari, Android, PC; keine Apple-Signierung nötig.
- `Android/` Android-Studio-Projekt; `app:assembleDebug` erzeugt Debug-APK.
- `iOS/` Xcode-Projekt mit aktivierter automatischer Signierung, aber ohne konkretes Apple-Developer-Team.
- `EXTRIBE-PRO-4.0-iPhone-Standalone.html` liegt zusätzlich außerhalb dieses Projektordners als eigenständige Safari-Datei vor.

## Wichtige Grenzen

- Die Projektdatei der älteren EX-TRIBE-3.1-Version kann nicht automatisch als neues v4-Pattern importiert werden.
- `Save` überschreibt den lokalen Projekt-Slot, `Export` sichert transportabel als JSON.
- Das Studio startet absichtlich NICHT mit dem gespeicherten Projekt, um die leere Vorlage zu bewahren. Speicherdaten werden nur per Menü geladen.
- iOS-Web-Audio und Sampleformate werden vom jeweiligen iOS-WebKit-Codec bestimmt; echte iPhone-Hardwaretests bleiben sinnvoll.
- Für eine auf iPhones installierbare signierte IPA brauchst du Apple-Developer-Team + Provisioning-Profil/Zertifikat. Ohne Signierung funktioniert die Safari-Webversion.
- MIDI/Native-CoreMIDI, Inter-App-Audio und Audio-Unit-Plug-ins sind in dieser Version nicht enthalten.

## Android

Android Studio öffnen: `Android/`, JDK 17, SDK API 35, Gradle 8.9, AGP 8.7.3. Build → Build APK(s).
Keine Mikrofon-/Internet-Berechtigung notwendig. Es werden nur Dateien geladen, die du im Dateiauswahlfenster auswählst.

## iOS

`iOS/EXTRIBE.xcodeproj` in Xcode öffnen. Simulator: ohne Signatur bauen. iPhone: Signing & Capabilities → dein Team wählen → automatische Signierung. Projekt-ID `de.orgoner.extribe` ggf. an die eigene Developer-ID anpassen.

## Browser auf dem iPhone

`web/` auf einem HTTPS-Server hosten und in Safari öffnen. Menü Share → Zum Home-Bildschirm. Für nur kurzzeitige Nutzung die eigenständige HTML-Datei nutzen.
