package de.orgoner.extribe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.util.UUID;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 1001;
    private static final int SAVE_FILE = 1002;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private OutputStream out;
    private boolean receiving;
    private boolean waitingForSave;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10, 15, 24));
        getWindow().setNavigationBarColor(Color.rgb(10, 15, 24));
        WebView.setWebContentsDebuggingEnabled(false);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new ExportBridge(), "AndroidExport");
        web.addJavascriptInterface(new ProjectStorage(), "AndroidProjectStorage");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                return !"file".equals(url.getScheme()) && !"about".equals(url.getScheme());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try { startActivityForResult(intent, PICK_FILE); return true; }
                catch (Exception ex) { chooser.onReceiveValue(null); chooser = null; return false; }
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private synchronized void closeOutput() {
        receiving = false;
        waitingForSave = false;
        if (out != null) { try { out.close(); } catch (IOException ignored) {} out = null; }
    }
    private void notifySaveReady(boolean ready) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__nativeExportReady(" + ready + ")", null); });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (chooser != null) {
                Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
                chooser.onReceiveValue(uri == null ? null : new Uri[]{uri});
                chooser = null;
            }
        } else if (requestCode == SAVE_FILE) {
            boolean ready = false;
            synchronized (this) {
                if (waitingForSave && resultCode == RESULT_OK && data != null && data.getData() != null) {
                    try { out = getContentResolver().openOutputStream(data.getData(), "w"); receiving = out != null; ready = receiving; }
                    catch (Exception ignored) { closeOutput(); }
                } else closeOutput();
                waitingForSave = false;
            }
            notifySaveReady(ready);
        }
    }
    private final class ProjectStorage {
        @JavascriptInterface public boolean save(String contents) {
            if (contents == null || contents.length() > 100 * 1048576) return false;
            try { Files.write(new File(getFilesDir(), "extribe-pro-project.json").toPath(), contents.getBytes(StandardCharsets.UTF_8));return true; }
            catch (Exception e) {return false;}
        }
        @JavascriptInterface public String load() {
            try { File f = new File(getFilesDir(), "extribe-pro-project.json"); if (!f.exists() || f.length() > 100 * 1048576) return "";
                return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
            } catch (Exception e) {return "";}
        }
    }
    private final class ExportBridge {
        @JavascriptInterface public void beginExport(String name, String mime) {
            String sanitized = name == null ? "EXTRIBE-Export.json" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (sanitized.isEmpty()) sanitized = "EXTRIBE-Export.json";
            if (sanitized.length() > 110) sanitized = sanitized.substring(0, 110);
            String type = mime != null && mime.matches("[a-zA-Z0-9.+_-]+/[a-zA-Z0-9.+_-]+") ? mime : "application/octet-stream";
            final String saveName = sanitized;
            runOnUiThread(() -> {
                closeOutput();
                waitingForSave = true;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(type);
                i.putExtra(Intent.EXTRA_TITLE, saveName);
                try { startActivityForResult(i, SAVE_FILE); }
                catch (Exception ex) { closeOutput(); notifySaveReady(false); }
            });
        }
        @JavascriptInterface public boolean writeChunk(String encoded) {
            if (encoded == null || encoded.length() > 65536) return false;
            synchronized (MainActivity.this) {
                if (!receiving || out == null) return false;
                try { out.write(Base64.decode(encoded, Base64.DEFAULT)); return true; }
                catch (Exception e) { closeOutput(); return false; }
            }
        }
        @JavascriptInterface public void endExport() {
            synchronized (MainActivity.this) { closeOutput(); }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export gespeichert", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void abortExport() { synchronized (MainActivity.this) { closeOutput(); } }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        closeOutput();
        if (chooser != null) { chooser.onReceiveValue(null); chooser = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
